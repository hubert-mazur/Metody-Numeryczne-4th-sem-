
#include <iostream>
#include <math.h>
#include <time.h>

const double min = 0;
const double max = 2*M_PI;
const int n = 100;
int MC;
int MS;

double f1 (double arg);
double f2 (double arg);
double f3 (double arg);
double approx (double *a, double *b, int MS, int MC, double arg);
double szum ();

void All (int MS, int MC, double *fp (double arg),const char *str);


int main ()
{
	MC = 5;
	MS = 5;

	double argumenty_f1 [n];
	double wartosci_f1 [n];

	argumenty_f1[0] = min;
	argumenty_f1[n-1] = max;
	double interval = ((max-min)/(n-1.0));

	for (int i=1;i<n-1;i++)
		argumenty_f1[i] = argumenty_f1[i-1] + interval;

	for (int i=0;i<n;i++)
		wartosci_f1[i] = f1(argumenty_f1[i]);

	double a[MS+1];
	double b[MC+1];

	double sum;

	for (int i=0;i<=MS;i++)
	{
		sum = 0;

		a[i]=2.0/n;
		for (int j=0;j<n;j++)
			sum += wartosci_f1[j] * sin(i*argumenty_f1[j]);
		a[i] *= sum;
	}

	for (int i=0;i<=MC;i++)
	{
		sum = 0;

		b[i] = 2.0/n;

		for (int j=0;j<n;j++)
			sum += wartosci_f1[j] * cos(i*argumenty_f1[j]);
		b[i] *= sum;
	}

	for (int i=0;i<=MS;i++)
		std::cout<<a[i]<<" ";
		std::cout<<std::endl;

	FILE *fp = fopen ("dane.dat","w");

	for (double i=0;i<max;i+= 0.01)
		fprintf (fp,"%lf %lf %lf\n",i,f1(i),approx(a,b,MS,MC,i));


}



double f1 (double arg)
{
	return (2*sin(arg)+sin(2*arg)+2*sin(3*arg));
}


double f2 (double arg)
{
	return (2*sin(arg)+sin(2*arg)+ 2*cos(arg) + cos(2*arg));
}
double f3 (double arg)
{
	return (2*sin(1.1*arg) + sin(2.1*arg) + 2*sin(3.1*arg));
}


double szum ()
{
	srand(time(NULL));
	return ((rand())/(RAND_MAX+1.0)-0.5);
}

double approx (double *a, double *b, int MS, int MC, double arg)
{
	double sum = 0;

	for (int i=0;i<=MS;i++)
	{
		sum += a[i]*sin(i*arg);
	}

	for (int i=0;i<=MC;i++)
	{
		sum += b[i]*cos(i*arg);
	}
}

void All (int MS, int MC, double *fp (double arg),const char *str)
{
	double argumenty_f [n];
	double wartosci_f [n];

	argumenty_f[0] = min;
	argumenty_f[n-1] = max;
	double interval = ((max-min)/(n-1.0));

	for (int i=1;i<n-1;i++)
		argumenty_f[i] = argumenty_f1[i-1] + interval;

	for (int i=0;i<n;i++)
		wartosci_f[i] =  *fp (argumenty_f[i]);

		double a[MS+1];
	double b[MC+1];

	double sum;

	for (int i=0;i<=MS;i++)
	{
		sum = 0;

		a[i]=2.0/n;
		for (int j=0;j<n;j++)
			sum += wartosci_f1[j] * sin(i*argumenty_f1[j]);
		a[i] *= sum;
	}

	for (int i=0;i<=MC;i++)
	{
		sum = 0;

		b[i] = 2.0/n;

		for (int j=0;j<n;j++)
			sum += wartosci_f1[j] * cos(i*argumenty_f1[j]);
		b[i] *= sum;
	}




}